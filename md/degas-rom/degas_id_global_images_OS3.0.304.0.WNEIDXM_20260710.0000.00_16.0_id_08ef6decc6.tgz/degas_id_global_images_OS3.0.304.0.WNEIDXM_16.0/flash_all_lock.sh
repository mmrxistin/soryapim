if [ -e $(dirname $0)/images/anti_version.txt ]; then
CURRENT_ANTI_VER=`cat $(dirname $0)/images/anti_version.txt`
fi
if [ -z "$CURRENT_ANTI_VER" ]; then CURRENT_ANTI_VER=0; fi
ver=`fastboot $* getvar anti 2>&1 | grep -oP "anti: \K[0-9]+"`
if [ -z "$ver" ]; then ver=0; fi
if [ $ver -gt $CURRENT_ANTI_VER ]; then echo "Current device antirollback version is greater than this pakcage"; exit 1; fi
fastboot $* getvar product 2>&1 | grep -E "degas|XIG07"
if [ $? -ne 0 ] ; then echo "Missmatching image and device"; exit 1; fi
SCRIPT_PATH=$(dirname $0)
handle_error(){
    echo $@
    exit 2;
}
fastboot $* flash gpt           ${SCRIPT_PATH}/images/PGPT_UFS          || handle_error flash gpt error
fastboot $* getvar crc 2>&1 | grep "^crc: 1"
if [ $? -eq 0 ]; then
fastboot $* flash crclist       ${SCRIPT_PATH}/images/crclist.txt       || handle_error flash crclist error
fastboot $* flash sparsecrclist ${SCRIPT_PATH}/images/sparsecrclist.txt || handle_error flash sparsecrclist error
fi

# erase opcust and opconfig when cota enabled; Judge whether the partition exists before erase;
fastboot $* getvar partition-type:opcust 2>&1 | grep "^partition-type:opcust: raw"
if [ $? -eq 0 ]; then
    fastboot $* erase opcust
    if [ $? -ne 0 ] ; then echo "Erase opcust error"; exit 1; fi
else
    fastboot $* getvar partition-type:opcust 2>&1 | grep "^partition-type:opcust: ext4"
    if [ $? -eq 0 ]; then
        fastboot $* erase opcust
        if [ $? -ne 0 ] ; then echo "Erase opcust error"; exit 1; fi
    else
        echo "No partition opcust found, skip erase opcust"
    fi
fi
fastboot $* getvar partition-type:opconfig 2>&1 | grep "^partition-type:opconfig: raw"
if [ $? -eq 0 ]; then
    fastboot $* erase opconfig
    if [ $? -ne 0 ] ; then echo "Erase opconfig error"; exit 1; fi
else
    fastboot $* getvar partition-type:opconfig 2>&1 | grep "^partition-type:opconfig: ext4"
    if [ $? -eq 0 ]; then
        fastboot $* erase opconfig
        if [ $? -ne 0 ] ; then echo "Erase opconfig error"; exit 1; fi
    else
        echo "No partition opconfig found, skip erase opconfig"
    fi
fi

fastboot $* erase boot_ab  || handle_error erase boot_ab error
fastboot $* erase expdb    || handle_error erase expdb error
fastboot $* erase metadata || handle_error erase metadata error
# erase countrycode_a when countrycode_a partition exist; Judge whether the partition exists before erase;
fastboot $* getvar partition-type:countrycode_a 2>&1 | grep "^partition-type:countrycode_a: raw"
if [ $? -eq 0 ]; then
    fastboot $* erase countrycode_ab
    if [ $? -ne 0 ] ; then echo "Erase countrycode_ab error"; exit 1; fi
else
    fastboot $* getvar partition-type:countrycode_a 2>&1 | grep "^partition-type:countrycode_a: ext4"
    if [ $? -eq 0 ]; then
        fastboot $* erase countrycode_ab
        if [ $? -ne 0 ] ; then echo "Erase countrycode_ab error"; exit 1; fi
    else
        echo "No partition countrycode_a found, skip erase opconfig"
    fi
fi

fastboot $* flash preloader_a     ${SCRIPT_PATH}/images/preloader_degas.bin || handle_error flash preloader_a error
fastboot $* flash preloader_b     ${SCRIPT_PATH}/images/preloader_degas.bin || handle_error flash preloader_b error
fastboot $* flash vbmeta_ab        ${SCRIPT_PATH}/images/vbmeta.img         || handle_error flash vbmeta_ab error
fastboot $* flash countrycode_ab   ${SCRIPT_PATH}/images/countrycode.img    || handle_error flash countrycode_ab error
fastboot $* flash vbmeta_system_ab ${SCRIPT_PATH}/images/vbmeta_system.img  || handle_error flash vbmeta_system_ab error
fastboot $* flash vbmeta_vendor_ab ${SCRIPT_PATH}/images/vbmeta_vendor.img  || handle_error flash vbmeta_vendor_ab error
fastboot $* flash modem_ab         ${SCRIPT_PATH}/images/modem.img          || handle_error flash modem_ab error
fastboot $* flash spmfw_ab         ${SCRIPT_PATH}/images/spmfw.img          || handle_error flash spmfw_ab error
fastboot $* flash mcf_ota_ab       ${SCRIPT_PATH}/images/mcf_ota.img        || handle_error flash mcf_ota_ab error
fastboot $* flash audio_dsp_ab     ${SCRIPT_PATH}/images/audio_dsp.img      || handle_error flash audio_dsp_ab error
fastboot $* flash pi_img_ab        ${SCRIPT_PATH}/images/pi_img.img         || handle_error flash pi_img_ab error
fastboot $* flash dpm_ab           ${SCRIPT_PATH}/images/dpm.img            || handle_error flash dpm_ab error
fastboot $* flash scp_ab           ${SCRIPT_PATH}/images/scp.img            || handle_error flash scp_ab error
fastboot $* flash ccu_ab           ${SCRIPT_PATH}/images/ccu.img            || handle_error flash ccu_ab error
fastboot $* flash vcp_ab           ${SCRIPT_PATH}/images/vcp.img            || handle_error flash vcp_ab error
fastboot $* flash sspm_ab          ${SCRIPT_PATH}/images/sspm.img           || handle_error flash sspm_ab error
fastboot $* flash mcupm_ab         ${SCRIPT_PATH}/images/mcupm.img          || handle_error flash mcupm_ab error
fastboot $* flash gpueb_ab         ${SCRIPT_PATH}/images/gpueb.img          || handle_error flash gpueb_ab error
fastboot $* flash apusys_ab        ${SCRIPT_PATH}/images/apusys.img         || handle_error flash apusys_ab error
fastboot $* flash mvpu_algo_ab     ${SCRIPT_PATH}/images/mvpu_algo.img      || handle_error flash mvpu_algo_ab error
fastboot $* flash gz_ab            ${SCRIPT_PATH}/images/gz.img             || handle_error flash gz_ab error
fastboot $* flash lk_ab            ${SCRIPT_PATH}/images/lk.img             || handle_error flash lk_ab error
fastboot $* flash vendor_boot_ab   ${SCRIPT_PATH}/images/vendor_boot.img    || handle_error flash vendor_boot_ab error
fastboot $* flash dtbo_ab          ${SCRIPT_PATH}/images/dtbo.img           || handle_error flash dtbo_ab error
fastboot $* flash tee_ab           ${SCRIPT_PATH}/images/tee.img            || handle_error flash tee_ab error
fastboot $* flash connsys_bt_ab    ${SCRIPT_PATH}/images/connsys_bt.img     || handle_error flash connsys_bt_ab error
fastboot $* flash connsys_wifi_ab  ${SCRIPT_PATH}/images/connsys_wifi.img   || handle_error flash connsys_wifi_ab error
fastboot $* flash connsys_gnss_ab  ${SCRIPT_PATH}/images/connsys_gnss.img   || handle_error flash connsys_gnss_ab error
fastboot $* flash logo_ab          ${SCRIPT_PATH}/images/logo.bin           || handle_error flash logo error
fastboot $* flash super            ${SCRIPT_PATH}/images/super.img          || handle_error flash super error
fastboot $* flash rescue           ${SCRIPT_PATH}/images/rescue.img         || handle_error flash rescue error
fastboot $* flash userdata         ${SCRIPT_PATH}/images/userdata.img       || handle_error flash userdata error
fastboot $* flash misc             ${SCRIPT_PATH}/images/misc.img           || handle_error flash misc error
fastboot $* flash boot_ab          ${SCRIPT_PATH}/images/boot.img           || handle_error flash boot_ab error
fastboot $* flash init_boot_ab     ${SCRIPT_PATH}/images/init_boot.img      || handle_error flash init_boot_ab error

fastboot $* oem cdms
fastboot $* set_active a  || handle_error set_active a error
fastboot $* oem lock || handle_error oem lock error
exit 0
